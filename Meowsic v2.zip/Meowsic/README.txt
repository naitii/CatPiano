Meowsic Cat Piano

Compatible with Kontakt 5.81 and higher.

One velocity layer, 28 notes with the A0 stretch to be an octave below and C3 to be a tenth above.

Adds kontakt effects "filter" "cat distortion" "delay" "reverb".

Effects are controlled by sliders for the following parameters:
	(CC22)filter 		= frequency
	(CC23)cat distortion	= distortion
	(CC24)delay		= delay time
	(CC25)reverb		= room size

